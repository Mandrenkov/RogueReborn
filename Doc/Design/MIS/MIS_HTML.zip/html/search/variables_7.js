var searchData=
[
  ['max_5ftype',['MAX_TYPE',['../classTrap.html#aaddd4a411ca407a197119c3fb9b12e80',1,'Trap']]],
  ['maxhp',['maxHP',['../classMob.html#acfc48942594e60e22eb3e46b257ef2ec',1,'Mob']]]
];
