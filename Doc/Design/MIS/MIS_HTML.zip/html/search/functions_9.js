var searchData=
[
  ['logscreen',['LogScreen',['../classLogScreen.html#aae5f3bbc0b5902e53e8d1350d9a4461f',1,'LogScreen']]]
];
