var searchData=
[
  ['ring_5ftuple_5ftype',['RING_TUPLE_TYPE',['../ring_8h.html#af8c1a4d67ffb0a904494177a010ede69',1,'ring.h']]]
];
