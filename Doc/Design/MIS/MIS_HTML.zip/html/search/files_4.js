var searchData=
[
  ['globals_2eh',['globals.h',['../globals_8h.html',1,'']]],
  ['goldpile_2ecpp',['goldpile.cpp',['../goldpile_8cpp.html',1,'']]],
  ['goldpile_2eh',['goldpile.h',['../goldpile_8h.html',1,'']]]
];
