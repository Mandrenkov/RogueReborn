var searchData=
[
  ['potion_5ftuple_5ftype',['POTION_TUPLE_TYPE',['../potion_8h.html#a492c7a925cbe63fee4d88a63f22f3113',1,'potion.h']]]
];
