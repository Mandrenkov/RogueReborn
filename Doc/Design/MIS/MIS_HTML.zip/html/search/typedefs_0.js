var searchData=
[
  ['armor_5ftuple_5ftype',['ARMOR_TUPLE_TYPE',['../armor_8h.html#ae0bc71ed2ae0b5b7f5f78eaaa733a478',1,'armor.h']]]
];
