var searchData=
[
  ['armor',['armor',['../classMob.html#a7741ba98d5a9c9446c4922c8457b6315',1,'Mob']]]
];
